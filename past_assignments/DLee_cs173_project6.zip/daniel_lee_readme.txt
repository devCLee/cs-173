This text file is for explaining what I observed for finding patterns in the project 6 program.

daniel_lee_1.txt:
This data file contains the input data that makes the program show a persisting pattern of four holes forming a square rotated 45 degrees (diamond square) that remains the same throughout the simulation.

daniel_lee_2.txt:
This data file contains the input data that makes the program show a repeated cycle pattern of vertical and horizontal line of three holes throughout the simulation.